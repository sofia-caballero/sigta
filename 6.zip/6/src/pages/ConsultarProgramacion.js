import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional';
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/consultartaller.css';

function ConsultarProgramacion() {
    const [programaciones, setProgramaciones] = useState([]);
    const [fichas, setFichas] = useState([]);
    const [profesionales, setProfesionales] = useState([]);
    const [talleres, setTalleres] = useState([]);
    const [instructores, setInstructores] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredProgramaciones, setFilteredProgramaciones] = useState([]);
    const [isSearchClicked, setIsSearchClicked] = useState(false);
    const [editIndex, setEditIndex] = useState(null);
    const [editProgramacion, setEditProgramacion] = useState({
        id: '',
        taller_id: '',
        ficha_id: '',
        profesional_1: '',
        profesional_2: '',
        instructor_id: '',
        fecha: '',
        hora: '',
        sede: '',
        estado: ''
    });
    const [rolUsuario, setRolUsuario] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        fetchProfesionales();
        fetchTalleres();
        fetchFichas();
        fetchInstructores();
        fetchProgramaciones();
    }, []);

    useEffect(() => {
        if (isSearchClicked) {
            const results = programaciones.filter(programacion =>
                (talleres.find(t => t.id === programacion.taller_id)?.nombre.toLowerCase().includes(searchTerm.toLowerCase())) ||
                (fichas.find(f => f.id === programacion.ficha_id)?.numero_ficha.toLowerCase().includes(searchTerm.toLowerCase()))
            );
            setFilteredProgramaciones(results);
        }
    }, [searchTerm, programaciones, isSearchClicked, talleres, fichas]);

    const fetchProgramaciones = () => {
        axios.get('http://localhost:4000/programacion')
            .then(response => {
                let programaciones = response.data;
                if (rolUsuario === 'Profesional') {
                    programaciones = programaciones.filter(programacion =>
                        programacion.profesional_1 === currentUserId ||
                        programacion.profesional_2 === currentUserId
                    );
                }
                setProgramaciones(programaciones);
            })
            .catch(error => {
                console.error('Error fetching programaciones:', error);
            });
    };

    const fetchFichas = () => {
        axios.get('http://localhost:4000/ficha')
            .then(response => {
                setFichas(response.data);
            })
            .catch(error => {
                console.error('Error fetching fichas:', error);
            });
    };

    const fetchProfesionales = () => {
        axios.get('http://localhost:4000/usuarios')
            .then(response => {
                const profesionales = response.data.filter(usuario => usuario.rol === 'Profesional');
                setProfesionales(profesionales);
                const usuarioActual = response.data.find(usuario => usuario.id === currentUserId);
                if (usuarioActual) {
                    setRolUsuario(usuarioActual.rol);
                }
            })
            .catch(error => console.error('Error fetching profesionales:', error));
    };

    const fetchTalleres = () => {
        axios.get('http://localhost:4000/taller')
            .then(response => {
                setTalleres(response.data);
            })
            .catch(error => {
                console.error('Error fetching talleres:', error);
            });
    };

    const fetchInstructores = () => {
        axios.get('http://localhost:4000/instructor')
            .then(response => {
                setInstructores(response.data);
            })
            .catch(error => {
                console.error('Error fetching instructores:', error);
            });
    };

    const handleSearch = () => {
        setIsSearchClicked(true);
    };

    const handleEdit = (index) => {
        setEditIndex(index);
        setEditProgramacion({ ...filteredProgramaciones[index] });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditProgramacion(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSave = () => {
        axios.put(`http://localhost:4000/programacion/${editProgramacion.id}`, editProgramacion)
            .then(response => {
                const updatedProgramaciones = [...filteredProgramaciones];
                updatedProgramaciones[editIndex] = response.data;
                setFilteredProgramaciones(updatedProgramaciones);
                setEditIndex(null);
            })
            .catch(error => {
                console.error('Error updating programacion:', error);
            });
    };

    const handleCancel = () => {
        setEditIndex(null);
    };

    const getFichaNumero = (fichaId) => {
        const ficha = fichas.find(f => f.id === fichaId);
        return ficha ? ficha.numero_ficha : 'Desconocido';
    };

    const getProfesionalNombre = (id) => {
        const profesional = profesionales.find(profesional => profesional.id === id);
        return profesional ? `${profesional.nombre || ''} ${profesional.apellido || ''}`.trim() : '';
    };

    const getTallerNombre = (tallerId) => {
        const taller = talleres.find(t => t.id === tallerId);
        return taller ? taller.nombre : 'Desconocido';
    };

    const getInstructorNombre = (instructorId) => {
        const instructor = instructores.find(i => i.id === instructorId);
        return instructor ? `${instructor.nombre || ''} ${instructor.apellido || ''}`.trim() : '';
    };

    const menuItems = [
        { nombre: 'Inicio', ruta: 'Home-page' },
        { nombre: 'Usuarios', ruta: '/usuarios' },
        { nombre: 'Ficha', ruta: '/consultar-ficha' },
        { nombre: 'Instructores', ruta: '/consultar-instructor' },
        { nombre: 'Profesional', ruta: '/consultar-profesional' },
        { nombre: 'Taller', ruta: '/consultar-taller' },
        { nombre: 'Horario Ficha', ruta: '/consultar-horario-ficha' },
        { nombre: 'Programacion', ruta: '/consultar-programacion' },
    ];

    const currentUserId = 'id_del_usuario_actual'; // Reemplaza esto con la lógica para obtener el ID del usuario actual

    return (
        <div style={{ display: 'flex' }}>
            <MenuDesplegable menuItems={menuItems} />
            <div style={{ flex: 1 }}>
                <EncabezadoProfesional nombreUsuario="Carla Sosa" rol="Administrador" imagenPerfil="ruta/a/imagen.jpg" />
                <div className="container">
                    <h1>Consultar Programación</h1>
                    <div className="search-bar">
                        <input
                            type="text"
                            placeholder="Buscar por nombre del taller o número de ficha"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                        <button onClick={handleSearch} className="search-button">
                            <span className="search-icon">🔍</span>
                        </button>
                    </div>
                    <button onClick={() => navigate('/CrearProgramacion')} className="create-button">
                        Crear Nueva Programación
                    </button>
                    <table className="estructura-table">
                        <thead>
                            <tr>
                                <th>Taller</th>
                                <th>Ficha</th>
                                <th>Profesional 1</th>
                                <th>Profesional 2</th>
                                <th>Instructor</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Sede</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {!isSearchClicked && (
                                <tr>
                                    <td colSpan="10">Haga una búsqueda para ver los datos aquí.</td>
                                </tr>
                            )}
                            {isSearchClicked && filteredProgramaciones.length === 0 && (
                                <tr>
                                    <td colSpan="10">No hay datos disponibles para la búsqueda.</td>
                                </tr>
                            )}
                            {isSearchClicked && filteredProgramaciones.length > 0 && filteredProgramaciones.map((programacion, index) => (
                                <tr key={programacion.id}>
                                    {editIndex === index ? (
                                        <>
                                            <td>
                                                <select
                                                    name="taller_id"
                                                    value={editProgramacion.taller_id}
                                                    onChange={handleInputChange}
                                                >
                                                    {talleres.map(taller => (
                                                        <option key={taller.id} value={taller.id}>
                                                            {taller.nombre}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td>
                                                <select
                                                    name="ficha_id"
                                                    value={editProgramacion.ficha_id}
                                                    onChange={handleInputChange}
                                                >
                                                    {fichas.map(ficha => (
                                                        <option key={ficha.id} value={ficha.id}>
                                                            {ficha.numero_ficha}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td>
                                                <select
                                                    name="profesional_1"
                                                    value={editProgramacion.profesional_1}
                                                    onChange={handleInputChange}
                                                >
                                                    {profesionales.map(profesional => (
                                                        <option key={profesional.id} value={profesional.id}>
                                                            {`${profesional.nombre || ''} ${profesional.apellido || ''}`.trim()}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td>
                                                <select
                                                    name="profesional_2"
                                                    value={editProgramacion.profesional_2}
                                                    onChange={handleInputChange}
                                                >
                                                    {profesionales.map(profesional => (
                                                        <option key={profesional.id} value={profesional.id}>
                                                            {`${profesional.nombre || ''} ${profesional.apellido || ''}`.trim()}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td>
                                                <select
                                                    name="instructor_id"
                                                    value={editProgramacion.instructor_id}
                                                    onChange={handleInputChange}
                                                >
                                                    {instructores.map(instructor => (
                                                        <option key={instructor.id} value={instructor.id}>
                                                            {`${instructor.nombre || ''} ${instructor.apellido || ''}`.trim()}
                                                        </option>
                                                    ))}
                                                </select>
                                            </td>
                                            <td>
                                                <input
                                                    type="date"
                                                    name="fecha"
                                                    value={editProgramacion.fecha}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="time"
                                                    name="hora"
                                                    value={editProgramacion.hora}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                            <select
                                                    type="text"
                                                    name="sede"
                                                    value={editProgramacion.sede}
                                                    onChange={handleInputChange}
                                                >
                                                    <option value="Calle 52">Calle 52</option>
                                <option value="Calle 64">Calle 64</option>
                                <option value="fontibón">fontibón</option>
                                                    </select>
                                            </td>
                                            <td>
                                                <select
                                                    name="estado"
                                                    value={editProgramacion.estado}
                                                    onChange={handleInputChange}
                                                >
                                                   <option value="">Seleccionar Estado</option>
                                <option value="Programado">Programado</option>
                                <option value="En Curso">En Curso</option>
                                <option value="Finalizado">Finalizado</option>
                                                </select>
                                            </td>
                                            <td>
                                                <button onClick={handleSave}>Guardar</button>
                                                <button onClick={handleCancel}>Cancelar</button>
                                            </td>
                                        </>
                                    ) : (
                                        <>
                                            <td>{getTallerNombre(programacion.taller_id)}</td>
                                            <td>{getFichaNumero(programacion.ficha_id)}</td>
                                            <td>{getProfesionalNombre(programacion.profesional_1)}</td>
                                            <td>{getProfesionalNombre(programacion.profesional_2)}</td>
                                            <td>{getInstructorNombre(programacion.instructor_id)}</td>
                                            <td>{programacion.fecha}</td>
                                            <td>{programacion.hora}</td>
                                            <td>{programacion.sede}</td>
                                            <td>{programacion.estado}</td>


                                            <td>
                                                <button onClick={() => handleEdit(index)}>Editar</button>
                                            </td>
                                        </>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default ConsultarProgramacion;
