import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional';
import BarraLateral from '../components/BarraLateral';
import './ConsultarProfesional.css';
import Cookies from 'universal-cookie';

const cookies = new Cookies();

function ConsultarProfesional() {
    const [profesionales, setProfesionales] = useState([]);
    const navigate = useNavigate();
    const rol = cookies.get('rol'); // Obtener el rol del usuario

    useEffect(() => {
        axios.get('http://localhost:4000/profesional')
            .then(response => {
                setProfesionales(response.data);
            })
            .catch(error => {
                console.error('Error al obtener los profesionales:', error);
            });
    }, []);

    const handleCreateClick = () => {
        navigate('/crear-profesional');
    };

    const menuItems = [
        { nombre: 'Inicio', ruta: 'Home-page' },
        { nombre: 'Usuarios', ruta: '/usuarios' },
        { nombre: 'Ficha', ruta: '/consultar-ficha' },
        { nombre: 'Instructores', ruta: '/consultar-instructor' },
        { nombre: 'Profesional', ruta: '/ConsultarHorarioProfesional' },
        { nombre: 'Taller', ruta: '/consultar-taller' },
        { nombre: 'Horario Ficha', ruta: '/consultar-horario-ficha' },
        { nombre: 'Programacion', ruta: '/consultar-programacion' },
    ];

    return (
        <div style={{ display: 'flex' }}>
            <BarraLateral menuItems={menuItems} />
            <div style={{ flex: 1 }}>
                <EncabezadoProfesional nombreUsuario="Carla Sosa" rol={rol} imagenPerfil="ruta/a/imagen.jpg" />
                <div className="container">
                    <h1>Consultar Profesionales</h1>
                    {/* Mostrar el botón de "Crear Profesional" solo si el rol es Coordinador */}
                    {rol === 'Coordinador' && (
                        <button className="create-button" onClick={handleCreateClick}>
                            Crear Profesional
                        </button>
                    )}
                    <table className="profesionales-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Número de Documento</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Rol</th>
                            </tr>
                        </thead>
                        <tbody>
                            {profesionales.map(profesional => (
                                <tr key={profesional.id}>
                                    <td>{profesional.id}</td>
                                    <td>{profesional.número_de_documento}</td>
                                    <td>{profesional.nombre}</td>
                                    <td>{profesional.correo}</td>
                                    <td>{profesional.rol}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default ConsultarProfesional;