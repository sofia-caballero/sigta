import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional';
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/CrearTaller.css';

function CrearFicha() {
    const [numeroFicha, setNumeroFicha] = useState('');
    const [programaFormacion, setProgramaFormacion] = useState('');
    const [sede, setSede] = useState('Sede La 52');
    const [fechaInicio, setFechaInicio] = useState('');
    const [fechaFin, setFechaFin] = useState('');
    const [estado, setEstado] = useState('Activo');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const nuevaFicha = {
            numero_ficha: numeroFicha,
            programa_formacion: programaFormacion,
            sede: sede,
            fecha_inicio: fechaInicio,
            fecha_fin: fechaFin,
            estado: estado
        };

        axios.post('http://localhost:4000/ficha', nuevaFicha)
            .then(response => {
                console.log('Ficha creada:', response.data);
                navigate('/ConsultarFicha');
            })
            .catch(error => {
                console.error('Error creando la ficha:', error);
            });
    };

    const menuItems = [
        { nombre: 'Inicio', ruta: 'Home-page' },
        { nombre: 'Usuarios', ruta: '/usuarios' },
        { nombre: 'Ficha', ruta: '/ConsultarFicha' },
        { nombre: 'Instructores', ruta: '/consultar-instructor' },
        { nombre: 'Profesional', ruta: '/consultar-profesional' },
        { nombre: 'Taller', ruta: '/consultar-taller' },
        { nombre: 'Horario Ficha', ruta: '/consultar-horario-ficha' },
        { nombre: 'Programacion', ruta: '/consultar-programacion' },
    ];

    return (
        <div style={{ display: 'flex' }}>
            <MenuDesplegable menuItems={menuItems} />
            <div style={{ flex: 1 }}>
                <EncabezadoProfesional nombreUsuario="Carla Sosa" rol="Administrador" imagenPerfil="ruta/a/imagen.jpg" />
                <div className="formularioContenedor">
                    <h1>Crear Nueva Ficha</h1>
                    <form onSubmit={handleSubmit} className="crear-taller-content">
                        <div className="form-group">
                            <label>Número de Ficha:</label>
                            <input
                                type="text"
                                value={numeroFicha}
                                onChange={e => setNumeroFicha(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Programa de Formación:</label>
                            <input
                                type="text"
                                value={programaFormacion}
                                onChange={e => setProgramaFormacion(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Sede:</label>
                            <select
                                value={sede}
                                onChange={e => setSede(e.target.value)}
                                required
                            >
                                <option value="Sede La 52">Sede La 52</option>
                                <option value="Sede La 63">Sede La 63</option>
                                <option value="Sede Fontibón">Sede Fontibón</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Fecha de Inicio:</label>
                            <input
                                type="date"
                                value={fechaInicio}
                                onChange={e => setFechaInicio(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Fecha de Fin:</label>
                            <input
                                type="date"
                                value={fechaFin}
                                onChange={e => setFechaFin(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label>Estado:</label>
                            <select
                                value={estado}
                                onChange={e => setEstado(e.target.value)}
                            >
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </div>
                        <button type="submit" className="submit-button">Crear Ficha</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CrearFicha;
