import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional';
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/consultar.css';

function ConsultarFicha() {
    const [fichas, setFichas] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredFichas, setFilteredFichas] = useState([]);
    const [isSearchClicked, setIsSearchClicked] = useState(false);
    const [editIndex, setEditIndex] = useState(null);
    const [editFicha, setEditFicha] = useState({
        id: '',
        numero_ficha: '',
        programa_formacion: '',
        sede: '',
        fecha_inicio: '',
        fecha_fin: '',
        estado: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        fetchFichas();
    }, []);

    useEffect(() => {
        if (isSearchClicked) {
            if (searchTerm === '') {
                setFilteredFichas([]);
            } else {
                const results = fichas.filter(ficha =>
                    (ficha.numero_ficha && ficha.numero_ficha.toLowerCase().includes(searchTerm.toLowerCase())) ||
                    (ficha.programa_formacion && ficha.programa_formacion.toLowerCase().includes(searchTerm.toLowerCase()))
                );
                setFilteredFichas(results);
            }
        }
    }, [searchTerm, fichas, isSearchClicked]);

    const fetchFichas = () => {
        axios.get('http://localhost:4000/ficha')
            .then(response => {
                setFichas(response.data);
            })
            .catch(error => {
                console.error('Error fetching fichas:', error);
            });
    };

    const handleSearch = () => {
        setIsSearchClicked(true);
    };

    const handleEdit = (index) => {
        setEditIndex(index);
        setEditFicha({ ...filteredFichas[index] });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditFicha(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSave = () => {
        axios.put(`http://localhost:4000/ficha/${editFicha.id}`, editFicha)
            .then(response => {
                const updatedFichas = [...filteredFichas];
                updatedFichas[editIndex] = response.data;
                setFilteredFichas(updatedFichas);
                setEditIndex(null);
            })
            .catch(error => {
                console.error('Error updating ficha:', error);
            });
    };

    const handleCancel = () => {
        setEditIndex(null);
    };

    const menuItems = [
        { nombre: 'Inicio', ruta: 'Home-page' },
        { nombre: 'Usuarios', ruta: '/usuarios' },
        { nombre: 'Ficha', ruta: '/consultar-ficha' },
        { nombre: 'Instructores', ruta: '/consultar-instructor' },
        { nombre: 'Profesional', ruta: '/consultar-profesional' },
        { nombre: 'Taller', ruta: '/consultar-taller' },
        { nombre: 'Horario Ficha', ruta: '/consultar-horario-ficha' },
        { nombre: 'Programacion', ruta: '/consultar-programacion' },
    ];

    return (
        <div style={{ display: 'flex' }}>
            <MenuDesplegable menuItems={menuItems} />
            <div style={{ flex: 1 }}>
                <EncabezadoProfesional nombreUsuario="Carla Sosa" rol="Administrador" imagenPerfil="ruta/a/imagen.jpg" />
                <div className="container">
                    <h1>Consultar Fichas</h1>
                    <div className="search-bar">
                        <input
                            type="text"
                            placeholder="Buscar por número de ficha o programa de formación"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                        <button onClick={handleSearch} className="search-button">
                            <span className="search-icon">🔍</span>
                        </button>
                    </div>
                    <button onClick={() => navigate('/CrearFicha')} className="create-button">
                        Crear Nueva Ficha
                    </button>
                    <table className="instructor-table">
                        <thead>
                            <tr>
                                <th>Número de Ficha</th>
                                <th>Programa de Formación</th>
                                <th>Sede</th>
                                <th>Fecha de Inicio</th>
                                <th>Fecha de Fin</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {!isSearchClicked && (
                                <tr>
                                    <td colSpan="7">Haga una búsqueda para ver los datos aquí.</td>
                                </tr>
                            )}
                            {isSearchClicked && filteredFichas.length === 0 && (
                                <tr>
                                    <td colSpan="7">No hay datos disponibles para la búsqueda.</td>
                                </tr>
                            )}
                            {isSearchClicked && filteredFichas.length > 0 && filteredFichas.map((ficha, index) => (
                                <tr key={ficha.id}>
                                    {editIndex === index ? (
                                        <>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="numero_ficha"
                                                    value={editFicha.numero_ficha}
                                                    onChange={handleInputChange}
                                                    disabled
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="programa_formacion"
                                                    value={editFicha.programa_formacion}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="text"
                                                    name="sede"
                                                    value={editFicha.sede}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="date"
                                                    name="fecha_inicio"
                                                    value={editFicha.fecha_inicio}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                                <input
                                                    type="date"
                                                    name="fecha_fin"
                                                    value={editFicha.fecha_fin}
                                                    onChange={handleInputChange}
                                                />
                                            </td>
                                            <td>
                                                <select
                                                    name="estado"
                                                    value={editFicha.estado}
                                                    onChange={handleInputChange}
                                                >
                                                    <option value="Activo">Activo</option>
                                                    <option value="Inactivo">Inactivo</option>
                                                </select>
                                            </td>
                                            <td>
                                                <button onClick={handleSave} className="update-button">Guardar</button>
                                                <button onClick={handleCancel} className="cancel-button">Cancelar</button>
                                            </td>
                                        </>
                                    ) : (
                                        <>
                                            <td>{ficha.numero_ficha}</td>
                                            <td>{ficha.programa_formacion}</td>
                                            <td>{ficha.sede}</td>
                                            <td>{ficha.fecha_inicio}</td>
                                            <td>{ficha.fecha_fin}</td>
                                            <td>{ficha.estado}</td>
                                            <td>
                                                <button onClick={() => handleEdit(index)} className="update-button">Actualizar</button>
                                            </td>
                                        </>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}

export default ConsultarFicha;
