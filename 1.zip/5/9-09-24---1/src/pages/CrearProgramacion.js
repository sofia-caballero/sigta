import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional';
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/consultar.css';

function CrearProgramacion() {
    const [talleres, setTalleres] = useState([]);
    const [fichas, setFichas] = useState([]);
    const [profesionales, setProfesionales] = useState([]);
    const [instructores, setInstructores] = useState([]);
    const [formData, setFormData] = useState({
        taller_id: '',
        ficha_id: '',
        profesional_1: '',
        profesional_2: '',
        instructor_id: '',
        fecha: '',
        hora: '',
        sede: '',
        estado: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        fetchTalleres();
        fetchFichas();
        fetchProfesionales();
        fetchInstructores();
    }, []);

    const fetchTalleres = () => {
        axios.get('http://localhost:4000/taller')
            .then(response => setTalleres(response.data))
            .catch(error => console.error('Error fetching talleres:', error));
    };

    const fetchFichas = () => {
        axios.get('http://localhost:4000/ficha')
            .then(response => setFichas(response.data))
            .catch(error => console.error('Error fetching fichas:', error));
    };

    const fetchProfesionales = () => {
        axios.get('http://localhost:4000/usuarios')
            .then(response => {
                const profesionales = response.data.filter(usuario => usuario.rol === 'Profesional');
                setProfesionales(profesionales);
            })
            .catch(error => console.error('Error fetching profesionales:', error));
    };

    const fetchInstructores = () => {
        axios.get('http://localhost:4000/instructor')
            .then(response => setInstructores(response.data))
            .catch(error => console.error('Error fetching instructores:', error));
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevFormData => ({
            ...prevFormData,
            [name]: value
        }));
    };

    const validateProfesionales = () => {
        return formData.profesional_1 !== formData.profesional_2;
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validateProfesionales()) {
            axios.post('http://localhost:4000/programacion', formData)
                .then(response => {
                    navigate('/ConsultarProgramacion'); // Redirige a la página de consulta
                })
                .catch(error => console.error('Error creating programacion:', error));
        } else {
            alert('No se puede seleccionar el mismo profesional para ambos campos.');
        }
    };

    const generarMensaje = () => {
        const tallerSeleccionado = talleres.find(taller => taller.id === parseInt(formData.taller_id));
        const fechaFormateada = formData.fecha ? new Date(formData.fecha).toLocaleDateString() : '';
        const horaFormateada = formData.hora ? formData.hora : '';

        return `Querido instructor, se ha programado un taller${tallerSeleccionado ? ` de ${tallerSeleccionado.nombre}` : ''} en su área el día ${fechaFormateada} a las ${horaFormateada}.`;
    };

    return (
        <div style={{ display: 'flex' }}>
            <MenuDesplegable menuItems={[
                { nombre: 'Inicio', ruta: 'Home-page' },
                { nombre: 'Usuarios', ruta: '/usuarios' },
                { nombre: 'Ficha', ruta: '/consultar-ficha' },  
                { nombre: 'Instructores', ruta: '/consultar-instructor' },
                { nombre: 'Profesional', ruta: '/consultar-profesional' },
                { nombre: 'Taller', ruta: '/consultar-taller' },
                { nombre: 'Horario Ficha', ruta: '/consultar-horario-ficha' },
                { nombre: 'Programacion', ruta: '/ConsultarProgramacion' },
            ]} />
            <div style={{ flex: 1 }}>
                <EncabezadoProfesional nombreUsuario="Carla Sosa" rol="Administrador" imagenPerfil="ruta/a/imagen.jpg" />
                <div className="formularioContenedor">
                    <h1>Crear Programación</h1>
                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="taller_id">Taller</label>
                            <select id="taller_id" name="taller_id" value={formData.taller_id} onChange={handleChange} required>
                                <option value="">Seleccionar Taller</option>
                                {talleres.map(taller => (
                                    <option key={taller.id} value={taller.id}>{taller.nombre}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="ficha_id">Ficha</label>
                            <select id="ficha_id" name="ficha_id" value={formData.ficha_id} onChange={handleChange} required>
                                <option value="">Seleccionar Ficha</option>
                                {fichas.map(ficha => (
                                    <option key={ficha.id} value={ficha.id}>{ficha.numero_ficha}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="profesional_1">Profesional 1</label>
                            <select id="profesional_1" name="profesional_1" value={formData.profesional_1} onChange={handleChange} required>
                                <option value="">Seleccionar Profesional 1</option>
                                {profesionales.map(profesional => (
                                    <option key={profesional.id} value={profesional.id}>{profesional.nombre}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="profesional_2">Profesional 2</label>
                            <select id="profesional_2" name="profesional_2" value={formData.profesional_2} onChange={handleChange} required>
                                <option value="">Seleccionar Profesional 2</option>
                                {profesionales.map(profesional => (
                                    <option key={profesional.id} value={profesional.id}>{profesional.nombre}</option>
                                ))}
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="instructor_id">Instructor</label>
                            <select id="instructor_id" name="instructor_id" value={formData.instructor_id} onChange={handleChange} required>
                                <option value="">Seleccionar Instructor</option>
                                {instructores.map(instructor => (
                                    <option key={instructor.id} value={instructor.id}>{instructor.nombre}</option>
                                ))}
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Mensaje</label>
                            <div className="mensaje-instructor">
                                <p>{generarMensaje()}</p>
                            </div>
                        </div>

                        <div className="form-group">
                            <label htmlFor="fecha">Fecha</label>
                            <input
                                type="date"
                                id="fecha"
                                name="fecha"
                                value={formData.fecha}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="hora">Hora</label>
                            <input
                                type="time"
                                id="hora"
                                name="hora"
                                value={formData.hora}
                                onChange={handleChange}
                                required
                            />
                        </div>
                        <div className="form-group">
                            <label htmlFor="sede">Sede</label>
                            <select id="sede" name="sede" value={formData.sede} onChange={handleChange} required>
                                <option value="">Seleccionar Sede</option>
                                <option value="Calle 52">Calle 52</option>
                                <option value="Calle 64">Calle 64</option>
                                <option value="fontibón">fontibón</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="estado">Estado</label>
                            <select id="estado" name="estado" value={formData.estado} onChange={handleChange} required>
                                <option value="">Seleccionar Estado</option>
                                <option value="Programado">Programado</option>
                                <option value="En Curso">En Curso</option>
                                <option value="Finalizado">Finalizado</option>
                            </select>
                        </div>
                        <button type="submit">Crear Programación</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default CrearProgramacion;
