import React, { useState, useEffect } from 'react';
import '../css/MenuDesplegable.css';
import Cookies from 'universal-cookie';

const cookies = new Cookies();

const MenuDesplegable = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    // Obtener el rol del usuario de las cookies
    const role = cookies.get('rol');
    setUserRole(role);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`menu-container ${isOpen ? 'open' : ''}`}>
      <button className="menu-btn" onClick={toggleMenu}>
        {isOpen ? '☰' : '☰'}
      </button>
      <nav className={`menu ${isOpen ? 'open' : ''}`}>
        <ul>
          {/* Opciones comunes a todos los roles */}
          <li><a href="#commonOption1"></a></li>

          {/* Opciones para el rol Administrador */}
          {userRole === 'Administrador' && (
 <>
    <li><a href="/Administrador">Inicio</a></li>
    <li><a href="/Menu">Usuarios</a></li>
    <li><a href="/ConsultarProfesional">Profesional</a></li>
    <li><a href="/ConsultarInstructor">Instructor</a></li>
    <li><a href="#coordOption1">horario</a></li>
    <li>
      <a href="#tallerMenu">Taller</a>
      <ul>
      <li><a href="/ConsultarTaller">Consultar Taller</a></li>
        <li><a href="/CrearTaller">Crear Taller</a></li>
        <li><a href="/Crearprogramacion">Programar taller</a></li>
        <li><a href="/ConsultarProgramacion">Consultar programacion</a></li>
      </ul>
    </li>
  </>
)}

          {/* Opciones para el rol Coordinador */}
          {userRole === 'Coordinador' && (
            <>
              <li><a href="/Coordinador">inicio</a></li>
              <li>
      <a href="#horario">horarios</a>
      <ul>
      <li><a href="/ConsultarHorarioFicha">horarios fichas</a></li>
        <li><a href="/CrearTaller">horarios profecionales</a></li>
      
      </ul>
    </li>
            </>
          )}

          {/* Opciones para el rol Profesional */}
          {userRole === 'Profesional' && (
            <>
              <li><a href="#profOption1">Opción Profesional 1</a></li>
              <li><a href="#profOption2">Opción Profesional 2</a></li>
            </>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default MenuDesplegable;
