import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import md5 from 'md5';
import Header from '../components/Header';
import ErrorModal from '../components/mensaje'; // Importa el componente ErrorModal
import '../css/Register.css';

const baseUrl = "http://localhost:4000/usuarios_pendientes"; // Apunta a usuarios pendientes

const Register = () => {
  const [form, setForm] = useState({
    número_de_documento: '', 
    nombre: '',
    correo: '',
    password: '',
    confirmPassword: ''
  });
  
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [errorModal, setErrorModal] = useState({ show: false, message: '' }); // Estado para controlar el modal

  const navigate = useNavigate();

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const toggleConfirmPasswordVisibility = () => {
    setShowConfirmPassword(!showConfirmPassword);
  };

  const isPasswordSecure = (password) => {
    const minLength = 8;
    const hasLetters = /[a-zA-Z]/.test(password);
    const hasNumbers = /\d/.test(password);
    return password.length >= minLength && hasLetters && hasNumbers;
  };

  const validateForm = () => {
    const { número_de_documento, nombre, correo, password, confirmPassword } = form;
    return (
      número_de_documento && 
      nombre && 
      correo &&
      password && 
      confirmPassword && 
      password === confirmPassword && 
      isPasswordSecure(password)
    );
  };

  const registrarUsuario = async () => {
    if (!validateForm()) {
      setErrorModal({
        show: true,
        message: 'Por favor, complete todos los campos y asegúrese de que las contraseñas coincidan y cumplan con los requisitos de seguridad.'
      });
      return;
    }

    try {
      const newUser = {
        número_de_documento: form.número_de_documento,
        nombre: form.nombre,
        correo: form.correo,
        password: md5(form.password),
        estado: 'Pendiente'
      };

      const response = await axios.post(baseUrl, newUser);

      if (response.status === 201) {
        setErrorModal({
          show: true,
          message: 'Su registro está pendiente de aprobación.'
        });
        navigate("/"); // Redirige al inicio de sesión
      } else {
        setErrorModal({
          show: true,
          message: 'No se pudo registrar el usuario.'
        });
      }
    } catch (error) {
      setErrorModal({
        show: true,
        message: 'Error al registrar el usuario. Inténtelo más tarde.'
      });
    }
  };

  const closeModal = () => {
    setErrorModal({ show: false, message: '' });
  };

  return (
    <div>
      <Header />
      <div className="containerPrincipalregistrar">
        <div className="containerSecundarioregistrar">
          <h2 className="form-title"></h2>
          
          <div className="form-group">
            <label>Número de Documento:</label>
            <br />
            <input
              type="text"
              className="form-control"
              name="número_de_documento"
              onChange={handleChange}
            />
            <br />
            <label>Nombre Completo:</label>
            <br />
            <input
              type="text"
              className="form-control"
              name="nombre"
              onChange={handleChange}
            />
            <br />
            <label>Correo Electrónico:</label>
            <br />
            <input
              type="email"
              className="form-control"
              name="correo"
              onChange={handleChange}
            />
            <br />
            <label>Contraseña:</label>
            <br />
            <div className="password-container">
              <input
                type={showPassword ? "text" : "password"}
                className="form-control"
                name="password"
                onChange={handleChange}
              />
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={togglePasswordVisibility}
              >
                {showPassword ? "❌" : "👁️"}
              </button>
            </div>
            <small className="text-muted">La contraseña debe tener al menos 8 caracteres, incluyendo letras y números.</small>
            <br />
            <label>Confirmación de Contraseña:</label>
            <br />
            <div className="password-container">
              <input
                type={showConfirmPassword ? "text" : "password"}
                className="form-control"
                name="confirmPassword"
                onChange={handleChange}
              />
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={toggleConfirmPasswordVisibility}
              >
                {showConfirmPassword ? "❌" : "👁️"}
              </button>
            </div>
            <br />
            <button
              className="btn btn-primary"
              onClick={registrarUsuario}
              disabled={!validateForm()} 
            >
              Enviar solicitud 
            </button>
            
          </div>
        </div>
      </div>

      {/* Modal para mostrar errores */}
      <ErrorModal
        show={errorModal.show}
        onClose={closeModal}
        message={errorModal.message}
      />
    </div>
  );
};

export default Register;
