import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional'; // Asegúrate de que la ruta sea correcta
import MenuDesplegable from '../components/MenuDesplegable'; // Asegúrate de que la ruta sea correcta
import '../css/CrearTaller.css';

function CrearTaller() {
    const [nombre, setNombre] = useState('');
    const [descripcion, setDescripcion] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const nuevoTaller = {
            nombre: nombre,
            descripcion: descripcion,
        };

        axios.post('http://localhost:4000/taller', nuevoTaller)
            .then(response => {
                console.log('Taller creado:', response.data);
                navigate('/ConsultarTaller'); // Redirige a la página de consultar taller
            })
            .catch(error => {
                console.error('Error creando el taller:', error);
            });
    };

    return (
        <div className="menu-page">
        <EncabezadoProfesional /> {/* Componente EncabezadoProfesional */}
        <MenuDesplegable /> {/* Componente MenuDesplegable */}
        
        <div className="formularioContenedor">
            
            <div className="crear-taller-content">
                <h1>Crear Nuevo Taller</h1>
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label>Nombre:</label>
                        <input
                            type="text"
                            value={nombre}
                            onChange={e => setNombre(e.target.value)}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label>Descripción:</label>
                        <input
                            type="text"
                            value={descripcion}
                            onChange={e => setDescripcion(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit" className="submit-button">Guardar Taller</button>
                </form>
            </div>
        </div>
       </div> 
    );
}

export default CrearTaller;
