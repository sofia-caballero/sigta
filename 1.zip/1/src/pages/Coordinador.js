import React from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'universal-cookie';
import '../css/Coordinador.css'; // Asegúrate de tener un archivo CSS adecuado para Coordinador

const cookies = new Cookies();

const Coordinador = () => {
  const navigate = useNavigate();

  const cerrarSesion = () => {
    // Eliminar cookies al cerrar sesión
    cookies.remove('id', { path: '/' });
    cookies.remove('número_de_documento', { path: '/' });
    cookies.remove('nombre', { path: '/' });
    cookies.remove('username', { path: '/' });
    cookies.remove('rol', { path: '/' });

    // Redirigir al login usando navigate
    navigate('/login');
  };

  return (
    <div className="coordinador">
      <header className="header">
        <h1>Bienvenido, Coordinador</h1>
      </header>

      <main className="main">
        <section className="welcome">
          <h2>Panel de Control</h2>
          <p>Aquí puedes gestionar las actividades de los grupos y ver los informes.</p>
        </section>

        <button className="logout-btn" onClick={cerrarSesion}>Cerrar Sesión</button>
      </main>
    </div>
  );
};

export default Coordinador;
