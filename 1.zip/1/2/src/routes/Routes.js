import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Login from '../pages/Login';
import Menu from '../pages/Menu';
import Register from '../pages/Register'; // Importa el componente Register
import Profesional from '../pages/Profesional'; // Importa el componente Profesional
import Coordinador from '../pages/Coordinador'; // Importa el componente Coordinador
import Inicio from '../pages/Inicio'; // Importa el componente Coordinador

function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Menu" element={<Menu />} />
        <Route path="/register" element={<Register />} />  {/* Ruta para el registro */}
        <Route path="/profesional" element={<Profesional />} />  {/* Ruta para Profesional */}
        <Route path="/coordinador" element={<Coordinador />} />  {/* Ruta para Coordinador */}
      </Routes>
    </BrowserRouter>
  );
}

export default AppRoutes;


