// src/components/Footer.js
import React from 'react';
import '../css/Footer.css'; // Importando los estilos desde la carpeta 'css'

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; 2024 SENA - Sistema de Gestión de Bienestar</p>
    </footer>
  );
};

export default Footer;
