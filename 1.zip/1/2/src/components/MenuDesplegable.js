// src/componentes/MenuDesplegable.jsx
import React, { useState } from 'react';
import '../css/MenuDesplegable.css';

const MenuDesplegable = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`menu-container ${isOpen ? 'open' : ''}`}>
      <button className="menu-btn" onClick={toggleMenu}>
        {isOpen ? '☰' : '☰'}
      </button>
      <nav className={`menu ${isOpen ? 'open' : ''}`}>
        <ul>
        <li><a href="#option1"></a></li>
          <li><a href="#option1">Opción 1</a></li>
          <li><a href="#option2">Opción 2</a></li>
          <li><a href="#option3">Opción 3</a></li>
          <li><a href="#option4">Opción 4</a></li>
        </ul>
      </nav>
    </div>
  );
};

export default MenuDesplegable;


