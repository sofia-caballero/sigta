import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import md5 from 'md5';
import Cookies from 'universal-cookie';
import { Navigate } from 'react-router-dom';
import logoSena from '../assets/logo_sena.png';
import '../css/Login.css';

const baseUrl = "http://localhost:3001/usuarios";
const cookies = new Cookies();

class Login extends Component {
  state = {
    form: {
      número_de_documento: '',
      password: ''
    },
    redirectTo: null,
    showPassword: false,
    error: false // Estado para controlar el error
  };

  handleChange = (e) => {
    this.setState({
      form: {
        ...this.state.form,
        [e.target.name]: e.target.value
      }
    });
  };

  togglePasswordVisibility = () => {
    this.setState({ showPassword: !this.state.showPassword });
  };

  iniciarSesion = async () => {
    try {
      const response = await axios.get(baseUrl, {
        params: {
          número_de_documento: this.state.form.número_de_documento,
          password: md5(this.state.form.password)
        }
      });

      if (response.data.length > 0) {
        const respuesta = response.data[0];
        cookies.set('id', respuesta.id, { path: "/" });
        cookies.set('número_de_documento', respuesta.número_de_documento, { path: "/" });
        cookies.set('nombre', respuesta.nombre, { path: "/" });
        cookies.set('username', respuesta.username, { path: "/" });
        cookies.set('rol', respuesta.rol, { path: "/" }); // Guarda el rol en cookies

        // Redirige según el rol del usuario
        switch (respuesta.rol) {
          case 'Administrador':
            this.setState({ redirectTo: '/Menu' }); // Redirige a la página de administrador
            break;
          case 'Profesional':
            this.setState({ redirectTo: '/profesional' });
            break;
          case 'Coordinador':
            this.setState({ redirectTo: '/coordinador' });
            break;
          default:
            alert('Rol desconocido');
            break;
        }
      } else {
        this.setState({ error: true }); // Marca el error en el estado
        alert('El número de documento o la contraseña no son correctos');
      }
    } catch (error) {
      console.error(error);
      this.setState({ error: true }); // Marca el error en el estado
    }
  };

  componentDidMount() {
    if (cookies.get('username')) {
      // Redirigir según el rol del usuario
      const rol = cookies.get('rol');
      if (rol === 'Administrador') {
        window.location.href = "/Menu"; // Redirige al panel de administrador
      } else if (rol === 'Profesional') {
        window.location.href = "/profesional"; // Redirige al panel de profesional
      } else if (rol === 'Coordinador') {
        window.location.href = "/coordinador"; // Redirige al panel de coordinador
      }
    }
  }

  render() {
    if (this.state.redirectTo) {
      return <Navigate to={this.state.redirectTo} />;
    }

    const buttonStyle = {
      backgroundColor: '#4CAF50', // Color verde claro
      color: 'white',
      border: 'none',
      cursor: 'pointer',
      padding: '10px 20px', // Tamaño fijo del botón
      fontSize: '16px', // Tamaño de fuente fijo
      borderRadius: '5px', // Bordes redondeados
      transition: 'background-color 0.3s ease', // Transición suave del color de fondo
    };

    return (
      <div className="containerPrincipal">
        <div className="containerSecundario">
          <div className="logo-container">
            <img src={logoSena} alt="Logo" className="logo" />
          </div>
          <div className="form-group">
            <label>Número de Documento:</label>
            <br />
            <input
              type="text"
              className="form-control"
              name="número_de_documento"
              onChange={this.handleChange}
            />
            <br />
            <label>Contraseña:</label>
            <br />
            <div className="password-container">
              <input
                type={this.state.showPassword ? "text" : "password"}
                className="form-control"
                name="password"
                onChange={this.handleChange}
              />
              <button
                type="button"
                className="btn btn-outline-secondary btn-sm"
                onClick={this.togglePasswordVisibility}
              >
                {this.state.showPassword ? "❌" : "👁️"}
              </button>
            </div>
            <br />
            <button
              style={buttonStyle}
              onClick={this.iniciarSesion}
            >
              Iniciar Sesión
            </button>
            <br /><br />
            <button className="btn btn-secondary" onClick={() => window.location.href = '/register'}>
              Registrar Usuario
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;
