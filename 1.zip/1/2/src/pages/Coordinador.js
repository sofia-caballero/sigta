import React from 'react';
import EncabezadoProfesional from '../components/EncabezadoProfesional'; // Asegúrate de importar correctamente
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/Coordinador.css'; // Asegúrate de tener un archivo CSS adecuado para Coordinador

const Coordinador = () => {
  return (
    <div className="Coordinador">
      <EncabezadoProfesional />
      <MenuDesplegable /> {/* Agrega el menú desplegable */}

      <main className="main">
        <section className="welcome">
          <h2>Panel de Control coordinador </h2>
          <p>Aquí puedes gestionar tus actividades y ver tus asignaciones.</p>
        </section>
      </main>
    </div>
  );
};

export default Coordinador;
