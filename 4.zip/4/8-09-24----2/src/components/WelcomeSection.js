// src/components/WelcomeSection.js
import React from 'react';
import '../css/WelcomeSection.css'; // Importa los estilos desde la carpeta 'css'
import artistImage from '../assets/im1.png'; // Reemplaza con tu imagen

const WelcomeSection = () => {
  return (
    <section className="welcome-section">
      <div className="welcome-content">
        <h1>Bienvenida al Sistema de Gestión de Talleres</h1>
        <p>Descubre un sistema diseñado para facilitar la programación de talleres, asegurando una experiencia fluida para los organizadores y participantes.</p>
        <button className="cta-button">Learn More</button>
      </div>
      <div className="welcome-image">
        <img src={artistImage} alt="Painting Artist" />
      </div>
    </section>
  );
};

export default WelcomeSection;