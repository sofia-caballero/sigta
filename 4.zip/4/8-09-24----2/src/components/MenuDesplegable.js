import React, { useState, useEffect } from 'react';
import '../css/MenuDesplegable.css';
import Cookies from 'universal-cookie';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHome, faUser, faCalendar, faTasks, faCog, faTimeline, faUsers } from '@fortawesome/free-solid-svg-icons';
import { faUserTie } from '@fortawesome/free-solid-svg-icons/faUserTie';
import { FaChalkboardTeacher } from 'react-icons/fa';
import { faChalkboardTeacher } from '@fortawesome/free-solid-svg-icons/faChalkboardTeacher';

const cookies = new Cookies();

const MenuDesplegable = () => {
  const [userRole, setUserRole] = useState('');
  const [tallerMenuOpen, setTallerMenuOpen] = useState(false); // Variable correcta

  useEffect(() => {
    // Obtener el rol del usuario de las cookies
    const role = cookies.get('rol');
    setUserRole(role);
  }, []);

  const toggleTallerMenu = () => {
    setTallerMenuOpen(!tallerMenuOpen); // Variable correcta
  };

  return (
    <div className="menu-container">
      <div className="menu-title">
        SIGTA
      </div>
      <nav className="menu">
        <ul>
          {/* Opciones para el rol Administrador */}
          {userRole === 'Administrador' && (
            <>
              <li><a href="/Administrador"><FontAwesomeIcon icon={faHome} /> Inicio</a></li>
              <li><a href="/Menu"><FontAwesomeIcon icon={faUsers} /> Usuarios</a></li>
              <li><a href="/ConsultarProfesional"><FontAwesomeIcon icon={faUserTie} /> Profesional</a></li>
              <li><a href="/ConsultarInstructor"><FontAwesomeIcon icon={faChalkboardTeacher} /> Instructor</a></li>
              <li><a href="#coordOption1"><FontAwesomeIcon icon={faCalendar} /> Horario</a></li>
              <li>
                <a href="#tallerMenu" onClick={toggleTallerMenu}>
                  <FontAwesomeIcon icon={faTasks} /> Taller
                </a>
                <ul className={`submenu ${tallerMenuOpen ? 'open' : ''}`}>
                  <li><a href="/ConsultarTaller">Consultar Taller</a></li>
                  <li><a href="/ConsultarProgramacion">Consultar Programación</a></li>
                </ul>
              </li>
            </>
          )}

          {/* Opciones para el rol Coordinador */}
          {userRole === 'Coordinador' && (
            <>
              <li><a href="/Coordinador"><FontAwesomeIcon icon={faHome} /> Inicio</a></li>
              <li>
                <a href="#horario"><FontAwesomeIcon icon={faCalendar} /> Horarios</a>
                <ul>
                  <li><a href="/ConsultarHorarioFicha">Horarios Fichas</a></li>
                  <li><a href="/CrearTaller">Horarios Profesionales</a></li>
                </ul>
              </li>
            </>
          )}

          {/* Opciones para el rol Profesional */}
          {userRole === 'Profesional' && (
            <>
             <li><a href="/Profesional"><FontAwesomeIcon icon={faHome} /> Inicio</a></li>
               <li><a href="/ConsultarTaller">Consultar Taller</a></li>
              <li><a href="/TalleresAsignados"><FontAwesomeIcon icon={faCog} /> TalleresAsignados</a></li>
            </>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default MenuDesplegable;

