import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import md5 from 'md5';
import Cookies from 'universal-cookie';
import { Navigate } from 'react-router-dom';
import logoSena from '../assets/logo_sena.png';
import Header from '../components/Header';
import ErrorModal from '../components/mensaje'; // Importar el componente ErrorModal
import '../css/Login.css';

const baseUrl = "http://localhost:4000/usuarios";
const cookies = new Cookies();

class Login extends Component {
  state = {
    form: {
      número_de_documento: '',
      password: ''
    },
    redirectTo: null,
    showPassword: false,
    error: false, // Estado para controlar el error
    errorMessage: '', // Mensaje de error
    showModal: false, // Estado para controlar el modal
  };

  handleChange = (e) => {
    this.setState({
      form: {
        ...this.state.form,
        [e.target.name]: e.target.value
      }
    });
  };

  togglePasswordVisibility = () => {
    this.setState({ showPassword: !this.state.showPassword });
  };

  handleCloseModal = () => {
    this.setState({ showModal: false });
  };

  iniciarSesion = async () => {
    try {
      const response = await axios.get(baseUrl, {
        params: {
          número_de_documento: this.state.form.número_de_documento,
          password: md5(this.state.form.password)
        }
      });

      if (response.data.length > 0) {
        const respuesta = response.data[0];
        cookies.set('id', respuesta.id, { path: "/" });
        cookies.set('número_de_documento', respuesta.número_de_documento, { path: "/" });
        cookies.set('nombre', respuesta.nombre, { path: "/" });
        cookies.set('username', respuesta.username, { path: "/" });
        cookies.set('rol', respuesta.rol, { path: "/" });

        switch (respuesta.rol) {
          case 'Administrador':
            this.setState({ redirectTo: '/administrador' });
            break;
          case 'Profesional':
            this.setState({ redirectTo: '/profesional' });
            break;
          case 'Coordinador':
            this.setState({ redirectTo: '/coordinador' });
            break;
          default:
            this.setState({ errorMessage: 'Rol desconocido', showModal: true });
            break;
        }
      } else {
        this.setState({ errorMessage: 'El número de documento o la contraseña no son correctos', showModal: true });
      }
    } catch (error) {
      console.error(error);
      this.setState({ errorMessage: 'Error en la conexión al servidor', showModal: true });
    }
  };

  componentDidMount() {
    if (cookies.get('username')) {
      const rol = cookies.get('rol');
      if (rol === 'Administrador') {
        window.location.href = "/administrador";
      } else if (rol === 'Profesional') {
        window.location.href = "/profesional";
      } else if (rol === 'Coordinador') {
        window.location.href = "/coordinador";
      }
    }
  }

  render() {
    if (this.state.redirectTo) {
      return <Navigate to={this.state.redirectTo} />;
    }

    const buttonStyle = {
      backgroundColor: '#4CAF50',
      color: 'white',
      border: 'none',
      cursor: 'pointer',
      padding: '10px 20px',
      fontSize: '16px',
      borderRadius: '5px',
      transition: 'background-color 0.3s ease',
    };

    return (
      <div>
        <Header />
        <div className="containerPrincipal">
          <div className="containerSecundario">
            <div className="logo-container">
              <img src={logoSena} alt="Logo" className="logo" />
            </div>
            <div className="form-group">
              <label>Número de Documento:</label>
              <br />
              <input
                type="text"
                className="form-control"
                name="número_de_documento"
                onChange={this.handleChange}
              />
              <br />
              <label>Contraseña:</label>
              <br />
              <div className="password-container">
                <input
                  type={this.state.showPassword ? "text" : "password"}
                  className="form-control"
                  name="password"
                  onChange={this.handleChange}
                />
                <button
                  type="button"
                  className="btn btn-outline-secondary btn-sm"
                  onClick={this.togglePasswordVisibility}
                >
                  {this.state.showPassword ? "❌" : "👁️"}
                </button>
              </div>
              <br />
              <button
                style={buttonStyle}
                onClick={this.iniciarSesion}
              >
                Iniciar Sesión
              </button>
              <br /><br />
              <button className="btn btn-secondary" onClick={() => window.location.href = '/register'}>
                Registrar Usuario
              </button>
            </div>
          </div>
        </div>

        {/* Modal de error */}
        <ErrorModal
          show={this.state.showModal}
          onClose={this.handleCloseModal}
          message={this.state.errorMessage}
        />
      </div>
    );
  }
}

export default Login;
