import React, { Component } from 'react';
import Cookies from 'universal-cookie';
import axios from 'axios';
import EncabezadoProfesional from '../components/EncabezadoProfesional'; // Asegúrate de que la ruta sea correcta
import MenuDesplegable from '../components/MenuDesplegable'; // Asegúrate de que la ruta sea correcta
import '../css/Menu.css';

const cookies = new Cookies();

class Menu extends Component {
    state = {
        usuariosPendientes: [],
        usuarios: [],
        roles: ["Profesional", "Coordinador"],
        selectedRoles: {}
    };

    componentDidMount() {
        if (!cookies.get('username')) {
            window.location.href = "./";
        } else {
            this.obtenerUsuariosPendientes();
            this.obtenerUsuarios();
        }
    }

    obtenerUsuariosPendientes = async () => {
        try {
            const response = await axios.get('http://localhost:4000/usuarios_pendientes');
            this.setState({ usuariosPendientes: response.data });
        } catch (error) {
            console.error('Error al obtener los usuarios pendientes:', error);
        }
    };

    obtenerUsuarios = async () => {
        try {
            const response = await axios.get('http://localhost:4000/usuarios');
            this.setState({ usuarios: response.data });
        } catch (error) {
            console.error('Error al obtener los usuarios:', error);
        }
    };

    handleAccept = async (id) => {
        try {
            const usuarioPendiente = this.state.usuariosPendientes.find(user => user.id === id);
            const selectedRole = this.state.selectedRoles[id] || "Profesional";

            if (usuarioPendiente) {
                const nuevoUsuario = { ...usuarioPendiente, rol: selectedRole };
                
                // Inserta en la tabla general de usuarios
                await axios.post('http://localhost:4000/usuarios', nuevoUsuario);

                // Inserta en la tabla correspondiente según el rol seleccionado con toda la información del usuario
                if (selectedRole === "Profesional") {
                    await axios.post('http://localhost:4000/profesional', {
                        idUsuario: usuarioPendiente.id,
                        nombre: usuarioPendiente.nombre,
                        correo: usuarioPendiente.correo,
                        password: usuarioPendiente.password
                    });
                } else if (selectedRole === "Coordinador") {
                    await axios.post('http://localhost:4000/coordinador', {
                        idUsuario: usuarioPendiente.id,
                        nombre: usuarioPendiente.nombre,
                        correo: usuarioPendiente.correo,
                        password: usuarioPendiente.password
                    });
                }

                // Elimina el usuario pendiente
                await this.handleReject(id);

                // Actualiza las listas
                this.obtenerUsuariosPendientes();
                this.obtenerUsuarios();
            }
        } catch (error) {
            console.error('Error al aceptar al usuario:', error);
        }
    };

    handleReject = async (id) => {
        try {
            await axios.delete(`http://localhost:4000/usuarios_pendientes/${id}`);
            this.obtenerUsuariosPendientes();
        } catch (error) {
            console.error('Error al rechazar al usuario:', error);
        }
    };

    handleRoleChange = (id, event) => {
        this.setState({
            selectedRoles: {
                ...this.state.selectedRoles,
                [id]: event.target.value
            }
        });
    };

    render() {
        return (
            <div className="menu-page">
                <EncabezadoProfesional /> {/* Componente EncabezadoProfesional */}
                <MenuDesplegable /> {/* Componente MenuDesplegable */}
                
                <div className="container">
                    <h2></h2>
                    <h1>Lista de usuarios pendientes</h1>

                    <table className="user-table">
                        <thead>
                            <tr>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Password</th>
                                <th>Rol</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.state.usuariosPendientes.map((usuario, index) => (
                                <tr key={index}>
                                    <td>{usuario.nombre}</td>
                                    <td>{usuario.correo}</td>
                                    <td>{usuario.password}</td>
                                    <td>
                                        <select
                                            onChange={(e) => this.handleRoleChange(usuario.id, e)}
                                            value={this.state.selectedRoles[usuario.id] || "Profesional"}
                                        >
                                            {this.state.roles.map((rol, index) => (
                                                <option key={index} value={rol}>{rol}</option>
                                            ))}
                                        </select>
                                    </td>
                                    <td>
                                        <button
                                            className="edit-btn"
                                            onClick={() => this.handleAccept(usuario.id)}
                                        >
                                            ✅
                                        </button>
                                        <button
                                            className="delete-btn"
                                            onClick={() => this.handleReject(usuario.id)}
                                        >
                                            🗑
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

export default Menu;
