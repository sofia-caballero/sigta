// src/componentes/EncabezadoProfesional.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'universal-cookie';
import { FaSignOutAlt, FaUserCircle } from 'react-icons/fa';
import '../css/EncabezadoProfesional.css'; // Importar el archivo CSS

const cookies = new Cookies();

const EncabezadoProfesional = () => {
  const [showOptions, setShowOptions] = useState(false);
  const navigate = useNavigate();

  const toggleOptions = () => setShowOptions(!showOptions);

  const cerrarSesion = () => {
    // Eliminar cookies al cerrar sesión
    cookies.remove('id', { path: '/' });
    cookies.remove('número_de_documento', { path: '/' });
    cookies.remove('nombre', { path: '/' });
    cookies.remove('username', { path: '/' });
    cookies.remove('rol', { path: '/' });

    // Redirigir al login
    navigate('/login');
  };

  return (
    <header className="encabezado-profesional">
      <div className="logo"></div>
      <div className="iconos">
        <button onClick={toggleOptions} className="avatar">
          <FaUserCircle />
        </button>
        {showOptions && (
          <div className="opciones">
            <button onClick={cerrarSesion} className="opcion">
              <FaSignOutAlt className="icono-salida" />
              Cerrar sesión
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default EncabezadoProfesional;
