import React, { useState, useEffect } from 'react';
import '../css/MenuDesplegable.css';
import Cookies from 'universal-cookie';

const cookies = new Cookies();

const MenuDesplegable = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    // Obtener el rol del usuario de las cookies
    const role = cookies.get('rol');
    setUserRole(role);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`menu-container ${isOpen ? 'open' : ''}`}>
      <button className="menu-btn" onClick={toggleMenu}>
        {isOpen ? '☰' : '☰'}
      </button>
      <nav className={`menu ${isOpen ? 'open' : ''}`}>
        <ul>
          {/* Opciones comunes a todos los roles */}
          <li><a href="#commonOption1"></a></li>

          {/* Opciones para el rol Administrador */}
          {userRole === 'Administrador' && (
            <>
              <li><a href="/Administrador">Inicio</a></li>
              <li><a href="/Menu">Usuarios</a></li>
              <li><a href="/CrearTaller">taller</a></li>
            </>
          )}

          {/* Opciones para el rol Coordinador */}
          {userRole === 'Coordinador' && (
            <>
              <li><a href="#coordOption1">Opción Coordinador 1</a></li>
              <li><a href="#coordOption2">Opción Coordinador 2</a></li>
            </>
          )}

          {/* Opciones para el rol Profesional */}
          {userRole === 'Profesional' && (
            <>
              <li><a href="#profOption1">Opción Profesional 1</a></li>
              <li><a href="#profOption2">Opción Profesional 2</a></li>
            </>
          )}
        </ul>
      </nav>
    </div>
  );
};

export default MenuDesplegable;
