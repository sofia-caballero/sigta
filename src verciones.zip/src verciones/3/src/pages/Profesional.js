// src/componentes/Profesional.jsx
import React from 'react';
import EncabezadoProfesional from '../components/EncabezadoProfesional'; // Asegúrate de importar correctamente
import MenuDesplegable from '../components/MenuDesplegable';
import '../css/Profesional.css';



const Profesional = () => {
  return (
    <div className="profesional">
      <EncabezadoProfesional />
      <MenuDesplegable /> {/* Agrega el menú desplegable */}

      <main className="main">
        <section className="welcome">
          <h2>Panel de Control</h2>
          <p>Aquí puedes gestionar tus actividades y ver tus asignaciones.</p>
        </section>
      </main>
    </div>
  );
};

export default Profesional;
