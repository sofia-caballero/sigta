import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import EncabezadoProfesional from '../components/EncabezadoProfesional'; // Asegúrate de que la ruta sea correcta
import MenuDesplegable from '../components/MenuDesplegable'; // Asegúrate de que la ruta sea correcta
import '../css/consultar.css';

function ConsultarProfesional() {
    const [profesionales, setProfesionales] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredProfesionales, setFilteredProfesionales] = useState([]);
    const [isSearchClicked, setIsSearchClicked] = useState(false);
    const [editIndex, setEditIndex] = useState(null);
    const [editProfesional, setEditProfesional] = useState({
        id: '',
        numero_documento: '',
        nombre: '',
        correo: ''
    });
    const navigate = useNavigate();

    useEffect(() => {
        fetchProfesionales();
    }, []);

    useEffect(() => {
        if (isSearchClicked) {
            if (searchTerm === '') {
                setFilteredProfesionales([]);
            } else {
                const results = profesionales.filter(profesional =>
                    (profesional.nombre && profesional.nombre.toLowerCase().includes(searchTerm.toLowerCase())) ||
                    (profesional.numero_documento && profesional.numero_documento.toLowerCase().includes(searchTerm.toLowerCase()))
                );
                setFilteredProfesionales(results);
            }
        }
    }, [searchTerm, profesionales, isSearchClicked]);

    const fetchProfesionales = () => {
        axios.get('http://localhost:4000/profesional')
            .then(response => {
                setProfesionales(response.data);
            })
            .catch(error => {
                console.error('Error fetching profesionales:', error);
            });
    };

    const handleSearch = () => {
        setIsSearchClicked(true);
    };

    const handleEdit = (index) => {
        setEditIndex(index);
        setEditProfesional({
            ...filteredProfesionales[index],
            numero_documento: filteredProfesionales[index].numero_documento
        });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setEditProfesional(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSave = () => {
        axios.put(`http://localhost:4000/profesional/${editProfesional.id}`, editProfesional)
            .then(response => {
                const updatedProfesionales = [...filteredProfesionales];
                updatedProfesionales[editIndex] = response.data;
                setFilteredProfesionales(updatedProfesionales);
                setEditIndex(null);
            })
            .catch(error => {
                console.error('Error updating profesional:', error);
            });
    };

    const handleCancel = () => {
        setEditIndex(null);
    };

    return (
        <div className="menu-page">
        <EncabezadoProfesional /> {/* Componente EncabezadoProfesional */}
        <MenuDesplegable /> {/* Componente MenuDesplegable */}
        
        <div className="container">
           
            <div className="main-content">
                
                <h1>Consultar Profesionales</h1>
                <div className="search-bar">
                    <input
                        type="text"
                        placeholder="Buscar por nombre o número de documento"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                    <button onClick={handleSearch} className="search-button">
                        <span className="search-icon">🔍</span>
                    </button>
                </div>
                <table className="instructor-table">
                    <thead>
                        <tr>
                            <th>Número de Documento</th>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {!isSearchClicked && (
                            <tr>
                                <td colSpan="4">Haga una búsqueda para ver los datos aquí.</td>
                            </tr>
                        )}
                        {isSearchClicked && filteredProfesionales.length === 0 && (
                            <tr>
                                <td colSpan="4">No hay datos disponibles para la búsqueda.</td>
                            </tr>
                        )}
                        {isSearchClicked && filteredProfesionales.length > 0 && filteredProfesionales.map((profesional, index) => (
                            <tr key={profesional.id}>
                                {editIndex === index ? (
                                    <>
                                        <td>
                                            <input
                                                type="text"
                                                name="numero_documento"
                                                value={editProfesional.numero_documento}
                                                onChange={handleInputChange}
                                                disabled
                                            />
                                        </td>
                                        <td>
                                            <input
                                                type="text"
                                                name="nombre"
                                                value={editProfesional.nombre}
                                                onChange={handleInputChange}
                                            />
                                        </td>
                                        <td>
                                            <input
                                                type="email"
                                                name="correo"
                                                value={editProfesional.correo}
                                                onChange={handleInputChange}
                                            />
                                        </td>
                                        <td>
                                            <button onClick={handleSave} className="update-button">Guardar</button>
                                            <button onClick={handleCancel} className="cancel-button">Cancelar</button>
                                        </td>
                                    </>
                                ) : (
                                    <>
                                        <td>{profesional.número_de_documento}</td>
                                        <td>{profesional.nombre}</td>
                                        <td>{profesional.correo}</td>
                                        <td>
                                            <button onClick={() => handleEdit(index)} className="update-button">Actualizar</button>
                                        </td>
                                    </>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    );
}

export default ConsultarProfesional;
