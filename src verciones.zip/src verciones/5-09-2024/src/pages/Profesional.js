
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'universal-cookie';
import '../css/Profesional.css';

const cookies = new Cookies();

const Profesional = () => {
  const navigate = useNavigate();

  const cerrarSesion = () => {
    // Eliminar cookies al cerrar sesión
    cookies.remove('id', { path: '/' });
    cookies.remove('número_de_documento', { path: '/' });
    cookies.remove('nombre', { path: '/' });
    cookies.remove('username', { path: '/' });
    cookies.remove('rol', { path: '/' });

    // Redirigir al login usando navigate
    navigate('/login');
  };

  return (
    <div className="profesional">
      <header className="header">
        <h1>Bienvenido, Profesional</h1>
      </header>

      <main className="main">
        <section className="welcome">
          <h2>Panel de Control</h2>
          <p>Aquí puedes gestionar tus actividades y ver tus asignaciones.</p>
        </section>

        <button className="logout-btn" onClick={cerrarSesion}>Cerrar Sesión</button>
      </main>
    </div>
  );
};

export default Profesional;
