import React, { Component } from 'react';
import Cookies from 'universal-cookie';
import axios from 'axios';
import '../css/Menu.css';

const cookies = new Cookies();

class Menu extends Component {
    state = {
        usuariosPendientes: [],
        usuarios: [], // Para almacenar la lista de usuarios existentes
        roles: ["Profesional", "Coordinador"],
        selectedRoles: {} // Para almacenar los roles seleccionados
    };

    componentDidMount() {
        if (!cookies.get('username')) {
            window.location.href = "./";
        } else {
            this.obtenerUsuariosPendientes();
            this.obtenerUsuarios(); // Obtener también la lista de usuarios existentes
        }
    }

    obtenerUsuariosPendientes = async () => {
        try {
            const response = await axios.get('http://localhost:3001/usuarios_pendientes');
            this.setState({ usuariosPendientes: response.data });
        } catch (error) {
            console.error('Error al obtener los usuarios pendientes:', error);
        }
    };

    obtenerUsuarios = async () => {
        try {
            const response = await axios.get('http://localhost:3001/usuarios');
            this.setState({ usuarios: response.data });
        } catch (error) {
            console.error('Error al obtener los usuarios:', error);
        }
    };

    handleAccept = async (id) => {
        try {
            // Encontrar el usuario pendiente por su ID
            const usuarioPendiente = this.state.usuariosPendientes.find(user => user.id === id);
            const selectedRole = this.state.selectedRoles[id] || "Profesional"; // Usa el rol seleccionado o "Profesional" por defecto

            if (usuarioPendiente) {
                // Crear un nuevo usuario con el rol seleccionado
                const nuevoUsuario = { ...usuarioPendiente, rol: selectedRole };

                // Añadir el nuevo usuario a la lista de usuarios
                await axios.post('http://localhost:3001/usuarios', nuevoUsuario);

                // Eliminar el usuario de la lista de pendientes
                await this.handleReject(id);

                // Actualizar la lista de usuarios pendientes y usuarios existentes
                this.obtenerUsuariosPendientes();
                this.obtenerUsuarios();
            }
        } catch (error) {
            console.error('Error al aceptar al usuario:', error);
        }
    };

    handleReject = async (id) => {
        try {
            // Eliminar el usuario pendiente
            await axios.delete(`http://localhost:3001/usuarios_pendientes/${id}`);

            // Actualizar la lista de usuarios pendientes
            this.obtenerUsuariosPendientes();
        } catch (error) {
            console.error('Error al rechazar al usuario:', error);
        }
    };

    handleRoleChange = (id, event) => {
        this.setState({
            selectedRoles: {
                ...this.state.selectedRoles,
                [id]: event.target.value
            }
        });
    };

    CerrarSesion = () => {
        cookies.remove('id', { path: "/" });
        cookies.remove('nombre', { path: "/" });
        cookies.remove('número_de_documento', { path: "/" });
        cookies.remove('username', { path: "/" });
        cookies.remove('rol', { path: "/" }); // Asegúrate de eliminar el rol
        window.location.href = './';
    };

    render() {
        return (
            <div className="container">
                <h2>Bienvenido Administrador {cookies.get('nombre')}</h2>
                <h3>Lista de usuarios pendientes</h3>
                <button className="logout-btn" onClick={this.CerrarSesion}>Cerrar Sesión</button>

                <table className="user-table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Correo</th>
                            <th>Password</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {this.state.usuariosPendientes.map((usuario, index) => (
                            <tr key={index}>
                                <td>{usuario.nombre}</td>
                                <td>{usuario.correo}</td>
                                <td>{usuario.password}</td>
                                <td>
                                    <select
                                        onChange={(e) => this.handleRoleChange(usuario.id, e)}
                                        value={this.state.selectedRoles[usuario.id] || "Profesional"}
                                    >
                                        {this.state.roles.map((rol, index) => (
                                            <option key={index} value={rol}>{rol}</option>
                                        ))}
                                    </select>
                                </td>
                                <td>
                                    <button
                                        className="edit-btn"
                                        onClick={() => this.handleAccept(usuario.id)}
                                    >
                                        ✅
                                    </button>
                                    <button
                                        className="delete-btn"
                                        onClick={() => this.handleReject(usuario.id)}
                                    >
                                        🗑
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        );
    }
}

export default Menu;
